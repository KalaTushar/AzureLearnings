﻿namespace BugTrackerManagement
{
    public class AppSettings
    {
        public string JwtSecret { get; set; }

    }
}
