﻿namespace BugTrackerManagement.Services
{
    public interface IAdminServices
    {
        Task<ReturnObject > DashboardStats();
    }
}
