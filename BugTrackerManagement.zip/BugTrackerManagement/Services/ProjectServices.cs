﻿using Microsoft.EntityFrameworkCore;
using BugTrackerManagement.DAL;
using BugTrackerManagement.Models;
using BugTrackerManagement.ViewModels;
using System;
using BugTrackerManagement.Exceptions;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;

namespace BugTrackerManagement.Services
{
    public class ProjectServices:IProjectServices
    {
        private readonly BugTrackerCatalogContext _context;

        public ProjectServices(BugTrackerCatalogContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<ProjectViewModel>> GetAllAsync()
        {
            return await _context.Projects
                .Select(p => new ProjectViewModel
                {
                    ProjectID=p.ProjectID,
                    ProjectName=p.ProjectName,
                    CurrentBugs=p.CurrentBugs.Select(p=>new Bug
                    {
                        BugID=p.BugID,
                        BugInfo=p.BugInfo,
                        BugState=p.BugState,
                        CurrentMessages=p.CurrentMessages,
                        ProjectID=p.ProjectID,
                    }).ToList(),
                })
                .ToListAsync();
        }
        public async Task<ProjectViewModel> GetByIdAsync(int id)
        {
            if(!await _context.Projects
                .AnyAsync(x => x.ProjectID == id))
            {
                throw new NotFoundException();
            }
            var t = await _context.Projects
                .FirstAsync(x => x.ProjectID == id);
            var ans = new ProjectViewModel
            {
                ProjectID= t.ProjectID,
                ProjectName=t.ProjectName,
                CurrentBugs = t.CurrentBugs.Select(p => new Bug
                {
                    BugID = p.BugID,
                    BugInfo = p.BugInfo,
                    BugState = p.BugState,
                    CurrentMessages = p.CurrentMessages,
                    ProjectID = p.ProjectID,
                }).ToList(),
            };

            return ans;
        }
        public async Task<ProjectViewModel> CreateAsync(ProjectCreateViewModel model)
        {
            var p = ToEntity(model);
            
            await _context.AddAsync(p);
            await _context.SaveChangesAsync();
            return ToViewModel(p);
        }
        

        
        private ProjectViewModel ToViewModel(Project p)
        {
            return new ProjectViewModel
            {
                ProjectID=p.ProjectID,
                ProjectName=p.ProjectName,
                CurrentBugs=p.CurrentBugs,
            };
        }
        private Project ToEntity(ProjectCreateViewModel p)
        {
            return new Project
            {
                ProjectName = p.ProjectName,
                CurrentBugs = new List<Bug>(),
            };
        }
    }
}
