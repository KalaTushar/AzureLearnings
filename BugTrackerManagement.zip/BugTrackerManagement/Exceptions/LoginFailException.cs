﻿namespace BugTrackerManagement.Exceptions
{
    public class LoginFailException:Exception
    {
    }
}
