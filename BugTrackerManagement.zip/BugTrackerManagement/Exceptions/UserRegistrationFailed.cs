﻿namespace BugTrackerManagement.Exceptions
{
    public class UserRegistrationFailed:Exception
    {

    }
}
