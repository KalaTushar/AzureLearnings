﻿namespace BugTrackerManagement.Exceptions
{
    public class NotFoundException : Exception
    {

    }
}
