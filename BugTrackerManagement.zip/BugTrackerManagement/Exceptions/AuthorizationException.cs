﻿namespace BugTrackerManagement.Exceptions
{
    public class AuthorizationException
    {

    }
}
