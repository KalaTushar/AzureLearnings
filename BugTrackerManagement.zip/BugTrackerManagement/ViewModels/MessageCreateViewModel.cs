﻿namespace BugTrackerManagement.ViewModels
{
    public class MessageCreateViewModel
    {
        public string MessageContext { get; set; }
        public bool MessageFlag { get; set; }
    }
}
