﻿namespace BugTrackerManagement.ViewModels
{
    public class BugCreateViewModel
    {
        public string BugInfo { get; set; }
    }
}
