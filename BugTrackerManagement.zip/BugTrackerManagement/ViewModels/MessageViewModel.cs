﻿namespace BugTrackerManagement.ViewModels
{
    public class MessageViewModel
    {
        public int MessageID { get; set; }
        public string MessageContext { get; set; }
        public bool MessageFlag { get; set; }
        public int BugID { get; set; }
    }
}
