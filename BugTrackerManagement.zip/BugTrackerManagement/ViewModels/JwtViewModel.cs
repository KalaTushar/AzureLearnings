﻿namespace BugTrackerManagement.ViewModels
{
    public class JwtViewModel
    {
        public string Jwt { get; set; }
    }
}
