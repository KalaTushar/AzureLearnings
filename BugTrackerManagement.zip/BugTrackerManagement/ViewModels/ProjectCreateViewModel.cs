﻿namespace BugTrackerManagement.ViewModels
{
    public class ProjectCreateViewModel
    {
        public string ProjectName { get; set; }
    }
}
